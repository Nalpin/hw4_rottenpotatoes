
Given /the following movies exist/ do |movies_table|
  movies_table.hashes.each do |movie|
    unless Movie.find_by_title(movie[:title])
      # debugger
      Movie.create(movie)
    end
  end
end

Then /the director of "(.*)" should be "(.*)"/ do |title, director|
  # debugger
  Movie.find_by_title(title)[:director].should == director
end

