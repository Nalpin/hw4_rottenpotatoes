require "spec_helper"

describe Movie do
  it {should respond_to(:find_similar)}
end
